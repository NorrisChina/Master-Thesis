#include "encoder/pmhid/pmhid.h"
#include <pybind11/numpy.h>
#include <pybind11/pybind11.h>
#include <pybind11/stl.h>

namespace py = pybind11;

template <typename T>
void bind_pmhid(py::module& m, const std::string& message) {
  py::class_<PMHID<T>>(m, message.c_str())
      .def(py::init<>())
      .def(
          "pmhid",
          [](PMHID<T>& self, py::array_t<T, py::array::c_style | py::array::forcecast> arr) {
            py::buffer_info info = arr.request();
            if (info.ndim != 1)
              throw std::runtime_error("Input message must be a 1-dimensional array");
            auto ptr = static_cast<T*>(info.ptr);
            std::vector<T> message(ptr, ptr + info.shape[0]);
            return self.pmhid(message);
          },
          py::arg("message"));
  ;
}

PYBIND11_MODULE(idcodes_pmhid, m) {
  m.doc() = "Pybind11 bindings for PMHID class";

  bind_pmhid<uint8_t>(m, "PMHID_U8");
  bind_pmhid<uint16_t>(m, "PMHID_U16");
  bind_pmhid<uint32_t>(m, "PMHID_U32");
  bind_pmhid<uint64_t>(m, "PMHID_U64");
}
