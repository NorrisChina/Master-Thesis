#include "encoder/polar/polar.h"
#include <pybind11/numpy.h>
#include <pybind11/pybind11.h>
#include <pybind11/stl.h>

namespace py = pybind11;

template <typename T>
void bind_polarfec(py::module& m, const std::string& class_name) {
  py::class_<POLARFEC<T>>(m, class_name.c_str())
      .def(py::init<uint32_t, uint32_t>())  // Default constructor

      // Bind polarfec function
      .def(
          "encode_polarfec",
          [](POLARFEC<T>& self, std::vector<bool>& data) {
            // Convert numpy arrays to raw pointer

            return self.encode_polarfec(data);
          },
          "Perform POLARFEC encoding", py::arg("data"))

      // Bind rsid_upto_gf2x16 function
      .def(
          "decode_polarfec",
          [](POLARFEC<T>& self, std::vector<double>& llr) {
            // Convert numpy arrays to raw pointer

            return self.decode_polarfec(llr);
          },
          "Perform POLARFEC encoding", py::arg("llr"));
}

PYBIND11_MODULE(idcodes_polarfec, m) {
  m.doc() = "Pybind11 bindings for POLARFEC class";  // Optional module docstring

  // Bind RSID for different template types
  bind_polarfec<uint8_t>(m, "POLARFEC_U8");
  bind_polarfec<uint16_t>(m, "POLARFEC_U16");
  bind_polarfec<uint32_t>(m, "POLARFEC_U32");
  bind_polarfec<uint64_t>(m, "POLARFEC_U64");
}
