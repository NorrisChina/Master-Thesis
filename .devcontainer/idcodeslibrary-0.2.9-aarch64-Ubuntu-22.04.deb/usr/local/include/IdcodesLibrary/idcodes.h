/**
 * @file idcodes.h
 * @brief A template wrapper class for handling various ID code operations.
 *
 * This file contains the definition of the IDCODES class, which provides a variety of methods
 * for generating and manipulating Galois Fields (GF), Reed-Solomon IDs (RSID), Reed-Muller IDs (RMID),
 * and SHA-based ID codes. It also includes methods for data processing and file processing.
 * 
 * The following methods are provided:
 * - generate_gf_outer: Generates the outer Galois Field.
 * - get_exp_arr: Returns the exponential array of the Galois Field.
 * - get_log_arr: Returns the logarithmic array of the Galois Field.
 * - get_exp_arr_in: Returns the inner exponential array of the Galois Field.
 * - get_log_arr_in: Returns the inner logarithmic array of the Galois Field.
 * - generate_gf_inner: Generates the inner Galois Field.
 * - save_outer_table: Saves the outer Galois Field table.
 * - save_inner_table: Saves the inner Galois Field table.
 * - rsid: Evaluates a codeword symbol (Tag value) using Reed-Solomon (RS) as Tagging codes.
 * - rsid_upto_gf2x16: Evaluates a Tag value using Reed-Solomon (RS) for GF exp (2^n; n =[1,16]) using lookup tables.
 * - rsid_upto_gf2x64: Evaluates a Tag value using Reed-Solomon (RS) for GF exp (2^n; n =[17,64]) using Hardware CLMUL Instructions.
 * - rs2id: Evaluates a Tag value using Reed-Solomon (RS) for GF exp (2^n; n =[1,64]) using two Galois Fields.
 * - rmid: Evaluates a Tag value using Reed-Muller (RM) codes.
 * - evaluate_rm_idcodes: Evaluates Reed-Muller ID codes.
 * - bit_shift_mul: Performs bit-shift multiplication.
 * - gf_mul: Performs Galois Field multiplication.
 * - initialize_gf: Initializes the Galois Field.
 * - carryless_mul_fast: Performs carry-less multiplication using hardware instructions.
 * - sha1id: Generates SHA-1 based ID codes.
 * - sha256id: Generates SHA-256 based ID codes.
 * - generate_string_sequence: Generates a sequence of strings.
 * - read_inputfile_sequence: Reads an input file and returns a sequence of data.
 * - string_to_numeric: Converts a string to a numeric representation.
 * - generate_message_vector: Generates a message vector of a specified size.
 * 
 * This class also includes private member objects for handling Galois Fields, Reed-Solomon IDs,
 * Reed-Muller IDs, SHA-1 and SHA-256 based ID codes, data processing, and file processing.
 * 
 * @tparam T The data type used for the operations.
 * 
 * @date July 1, 2025
 * @version 0.2.9.0
 * Proprietary Software License Agreement
 */

#ifndef ID_CODES_H
#define ID_CODES_H

#include "encoder/encoder.h"
#include "util/dataprocessing.h"
#include "util/fileprocessing.h"

/**
 * @class IDCODES
 * @brief A template wrapper class for handling various ID code operations.
 *
 * This class provides a variety of methods for generating and manipulating Galois Fields (GF),
 * Reed-Solomon IDs (RSID), Reed-Muller IDs (RMID), and SHA-based ID codes. It also includes
 * methods for data processing and file processing.
 *
 * @tparam T The data type used for the operations.
 */
template <typename T>
class IDCODES {
 public:
  void generate_gf_outer(const uint16_t gf_exp) { en_obj.generate_gf_outer(gf_exp); }

  std::vector<T> get_exp_arr() { return en_obj.get_exp_arr(); }

  std::vector<T> get_log_arr() { return en_obj.get_log_arr(); }

  std::vector<T> get_exp_arr_in() { return en_obj.get_exp_arr_in(); }

  std::vector<T> get_log_arr_in() { return en_obj.get_log_arr_in(); }

  void generate_gf_inner(const uint16_t gf_exp) { en_obj.generate_gf_inner(gf_exp); }

  void save_outer_table(int gf_size) { en_obj.save_outer_table(gf_size); }
  void save_inner_table(int gf_size) { en_obj.save_inner_table(gf_size); }

  T rsid(const std::vector<T>& message, T tag_pos, const T* exp_arr, const T* log_arr,
         const uint16_t gf_exp) {
    return en_obj.rsid(message, tag_pos, exp_arr, log_arr, gf_exp);
  }

  T rsid_upto_gf2x16(const std::vector<T>& message, const T tag_pos, const T* exp_arr,
                     const T* log_arr, uint32_t gf_size) {
    return en_obj.rsid_upto_gf2x16(message, tag_pos, exp_arr, log_arr, gf_size);
  }

  uint64_t rsid_upto_gf2x64(const std::vector<T>& message, const uint64_t tag_pos,
                            const uint16_t gf_exp) {
    return en_obj.rsid_upto_gf2x64(message, tag_pos, gf_exp);
  }

  T rs2id(const std::vector<T>& message, const T tag_pos, const T tag_pos_in, const T* exp_arr,
          const T* log_arr, const T* exp_arr_in, const T* log_arr_in, const uint16_t gf_exp) {
    return en_obj.rs2id(message, tag_pos, tag_pos_in, exp_arr, log_arr, exp_arr_in, log_arr_in,
                        gf_exp);
  }

  T rmid(const std::vector<T>& message, const T tag_pos, const T rm_order, const T* exp_arr,
         const T* log_arr, const uint16_t gf_exp) {
    return en_obj.rmid(message, tag_pos, rm_order, exp_arr, log_arr, gf_exp);
  }

  T bit_shift_mul(T a, T b, T field_gen_poly, T msb_mask) {
    return en_obj.bit_shift_mul(a, b, field_gen_poly, msb_mask);
  }

  T gf_mul(T a, T b, const T* exp_arr, const T* log_arr, const uint32_t gf_size) {
    return en_obj.gf_mul(a, b, exp_arr, log_arr, gf_size);
  }

  void initialize_gf(T* exp_arr, T* log_arr, const uint16_t gf_exp) {
    en_obj.initialize_gf(exp_arr, log_arr, gf_exp);
  }

  uint64_t carryless_mul_fast(uint64_t a, uint64_t b, uint16_t gf_exp) {
    return en_obj.carryless_mul_fast(a, b, gf_exp);
  }

  T sha1id(const std::vector<T>& data, const T tag_pos) { return en_obj.sha1id(data, tag_pos); }

  T sha256id(const std::vector<T>& data, const T tag_pos) { return en_obj.sha256id(data, tag_pos); }

  std::vector<T> generate_string_sequence(int length) {
    return dp_obj.generate_string_sequence(length);
  }

  std::vector<T> read_inputfile_sequence(const std::string& filename, bool binary) {
    return dp_obj.read_inputfile_sequence(filename, binary);
  }

  std::vector<unsigned char> string_to_numeric(const std::string& str) {
    return dp_obj.string_to_numeric(str);
  }
  std::vector<T> generate_message_vector(size_t size_in_KB, uint16_t gf_exp) {
    return dp_obj.generate_message_vector(size_in_KB, gf_exp);
  }

  T generate_random_tag_pos(T tags_size) { return dp_obj.generate_random_tag_pos(tags_size); }

  void create_file(const std::string& filepath, uint64_t size_in_B, uint16_t gf_exp) {
    dp_obj.create_file(filepath, size_in_B, gf_exp);
  }

  std::vector<T> read_file(const std::string& filepath, uint16_t gf_exp) {
    return dp_obj.read_file(filepath, gf_exp);
  }
  std::string generate_string(int length) { return dp_obj.generate_string(length); }

  uint64_t pmhid(const std::vector<T>& message) { return en_obj.pmhid(message); }

 private:
  Encoder<T> en_obj;
  DataProcessing<T> dp_obj;
  FileProcessing fp_obj;
};

#endif  // ID_CODES_H
