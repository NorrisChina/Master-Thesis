/**
 * @file encoder.h
 * @brief Header file for the encoder module.
 *
 * This file includes all necessary headers for the encoder module.
 * It provides the interface for encoding functionalities using various
 * encoding schemes and algorithms.
 *
 * Included headers:
 * - gf.h: Galois Field arithmetic operations.
 * - rmid.h: Reed-Muller ID encoding.
 * - rs2id.h: Reed-Solomon Inner ID encoding.
 * - rsid.h: Reed-Solomon ID encoding.
 * - sha1id.h: SHA-1 ID encoding.
 * - sha256id.h: SHA-256 ID encoding.
 *
 * @note Ensure that all included headers are available in the specified paths.
 */
#ifndef ENCODER_H
#define ENCODER_H

#include <iostream>
#include "gf/gf.h"
#include "pmhid/pmhid.h"
#include "rmid/rmid.h"
#include "rs2id/rs2id.h"
#include "rsid/rsid.h"
#include "sha1id/sha1id.h"
#include "sha256id/sha256id.h"

/**
 * @class Encoder
 * @brief A simple Encoder class.
 *
 * This class provides a variety of methods for generating and manipulating Galois Fields (GF),
 * Reed-Solomon IDs (RSID), Reed-Muller IDs (RMID), and SHA-based ID codes.
 */
template <typename T>
class Encoder {
  //TODO fix the encoder class
 public:
  void generate_gf_outer(const uint16_t gf_exp) { gf_obj.generate_gf_outer(gf_exp); }

  std::vector<T> get_exp_arr() { return gf_obj.get_exp_arr(); }

  std::vector<T> get_log_arr() { return gf_obj.get_log_arr(); }

  std::vector<T> get_exp_arr_in() { return gf_obj.get_exp_arr_in(); }

  std::vector<T> get_log_arr_in() { return gf_obj.get_log_arr_in(); }

  void generate_gf_inner(const uint16_t gf_exp) { gf_obj.generate_gf_inner(gf_exp); }

  void save_outer_table(int gf_size) { gf_obj.save_outer_table(gf_size); }
  void save_inner_table(int gf_size) { gf_obj.save_inner_table(gf_size); }

  T rsid(const std::vector<T>& message, T tag_pos, const T* exp_arr, const T* log_arr,
         const uint16_t gf_exp) {
    return rsid_obj.rsid(message, tag_pos, exp_arr, log_arr, gf_exp);
  }

  T rsid_upto_gf2x16(const std::vector<T>& message, const T tag_pos, const T* exp_arr,
                     const T* log_arr, uint32_t gf_size) {
    return rsid_obj.rsid_upto_gf2x16(message, tag_pos, exp_arr, log_arr, gf_size);
  }

  uint64_t rsid_upto_gf2x64(const std::vector<T>& message, const uint64_t tag_pos,
                            const uint16_t gf_exp) {
    return rsid_obj.rsid_upto_gf2x64(message, tag_pos, gf_exp);
  }

  T rs2id(const std::vector<T>& message, const T tag_pos, const T tag_pos_in, const T* exp_arr,
          const T* log_arr, const T* exp_arr_in, const T* log_arr_in, const uint16_t gf_exp) {
    return rs2id_obj.rs2id(message, tag_pos, tag_pos_in, exp_arr, log_arr, exp_arr_in, log_arr_in,
                           gf_exp);
  }

  T rmid(const std::vector<T>& message, const T tag_pos, const T rm_order, const T* exp_arr,
         const T* log_arr, const uint16_t gf_exp) {
    return rmid_obj.rmid(message, tag_pos, rm_order, exp_arr, log_arr, gf_exp);
  }

  T bit_shift_mul(T a, T b, T field_gen_poly, T msb_mask) {
    return gf_obj.bit_shift_mul(a, b, field_gen_poly, msb_mask);
  }

  T gf_mul(T a, T b, const T* exp_arr, const T* log_arr, const uint32_t gf_size) {
    return gf_obj.gf_mul(a, b, exp_arr, log_arr, gf_size);
  }

  void initialize_gf(T* exp_arr, T* log_arr, const uint16_t gf_exp) {
    gf_obj.initialize_gf(exp_arr, log_arr, gf_exp);
  }

  uint64_t carryless_mul_fast(uint64_t a, uint64_t b, uint16_t gf_exp) {
    return gf_obj.carryless_mul_fast(a, b, gf_exp);
  }

  T sha1id(const std::vector<T>& data, const T tag_pos) { return sha1id_obj.sha1id(data, tag_pos); }

  T sha256id(const std::vector<T>& data, const T tag_pos) {
    return sha256id_obj.sha256id(data, tag_pos);
  }
  uint64_t pmhid(const std::vector<T>& message) { return pmhid_obj.pmhid(message); }

 private:
  GF<T> gf_obj;
  RSID<T> rsid_obj;
  RS2ID<T> rs2id_obj;
  RMID<T> rmid_obj;
  SHA1ID<T> sha1id_obj;
  SHA256ID<T> sha256id_obj;
  PMHID<T> pmhid_obj;
};
#endif  // ENCODER_H
