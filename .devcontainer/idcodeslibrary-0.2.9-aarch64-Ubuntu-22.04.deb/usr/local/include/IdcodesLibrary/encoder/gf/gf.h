/**
 * @file gf.h
 * @brief Template class for operations in Galois Field (GF).
 *
 * This file contains the definition of the GF class, which provides methods to generate lookup tables,
 * perform multiplications, and save tables for Galois Fields. It supports both outer and inner Galois Fields
 * and provides methods for carryless multiplication using bit-shifts and intrinsic hardware instructions.
 * 
 * The following methods are provided:
 * - generate_gf_outer: Generates lookup tables (Exponential and Logarithmic) for Galois Field.
 * - generate_gf_inner: Generates lookup tables (Exponential and Logarithmic) for Inner Galois Field.
 * - save_outer_table: Saves the lookup tables for Galois Field.
 * - save_inner_table: Saves the lookup tables for Inner Galois Field.
 * - bit_shift_mul: Performs manual carryless multiplication of two operands using bit-shifts.
 * - gf_mul: Multiplies two operands using the pre-computed (Exponential and Logarithmic) lookup tables.
 * - initialize_gf: Generates exponential and logarithm lookup tables for GF.
 * - carryless_mul_fast: Performs carryless multiplication of two operands using intrinsic hardware instructions.
 * - get_exp_arr: Returns the exponential lookup table for outer GF.
 * - get_log_arr: Returns the logarithmic lookup table for outer GF.
 * - get_exp_arr_in: Returns the exponential lookup table for inner GF.
 * - get_log_arr_in: Returns the logarithmic lookup table for inner GF.
 * 
 * This class also includes private member objects for handling the lookup tables for both outer and inner Galois Fields.
 * 
 * @tparam T Data type for the elements in the Galois Field (e.g., uint8_t, uint16_t, uint32_t, uint64_t).
 * 
 * @date July 1, 2025
 * @version 0.2.9.0
 * Proprietary Software License Agreement
 */
#ifndef ENCODER_GF_H
#define ENCODER_GF_H

#include <cmath>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <vector>
#include "../../Types.h"
#ifdef __ARM_NEON
#include <arm_neon.h>
#else
#include <wmmintrin.h>  // For _mm_clmulepi64_si128 (PCLMULQDQ)
#endif

/**
 * @class GF
 * @brief Template class for operations in Galois Field (GF).
 * 
 * This class provides methods to generate lookup tables, perform multiplications,
 * and save tables for Galois Fields. It supports both outer and inner Galois Fields
 * and provides methods for carryless multiplication using bit-shifts and intrinsic
 * hardware instructions.
 * 
 * @tparam T Data type for the elements in the Galois Field (e.g., uint8_t, uint16_t, uint32_t, uint64_t).
 */
template <typename T>
class GF {
 public:
  /**
   * @brief Generates lookup tables (Exponential and Logarithmic) for Galois Field.
   * 
   * @param gf_exp Exponent for GF (2^gf_exp) within range [1,16].
   */
  void generate_gf_outer(const uint16_t gf_exp);

  /**
   * @brief Generates lookup tables (Exponential and Logarithmic) for Inner Galois Field.
   * 
   * @param gf_exp Exponent for GF (2^gf_exp) within range [1,16].
   */
  void generate_gf_inner(const uint16_t gf_exp);

  /**
   * @brief Saves the lookup tables for Galois Field.
   * 
   * @param gf_size Size of GF.
   */
  void save_outer_table(int gf_size);

  /**
   * @brief Saves the lookup tables for Inner Galois Field.
   * 
   * @param gf_size Size of GF.
   */
  void save_inner_table(int gf_size);

  /**
   * @brief Performs manual carryless multiplication of two operands using bit-shifts.
   * 
   * @tparam T Data type (e.g., uint8_t, uint16_t, uint32_t, uint64_t). 
   * @param a First operand.
   * @param b Second operand.
   * @param field_gen_poly Primitive and Irreducible Field generator polynomial for GF.
   * @param msb_mask Masking for correct modulus with field_gen_poly such that elements stay within desired GF.
   * @return T Result of the carryless multiplication.
   */
  T bit_shift_mul(T a, T b, T field_gen_poly, T msb_mask);

  /**
   * @brief Multiplies two operands using the pre-computed (Exponential and Logarithmic) lookup tables.
   * 
   * @tparam T Data type (e.g., uint8_t, uint16_t, uint32_t, uint64_t). 
   * @param a First operand.
   * @param b Second operand.
   * @param exp_arr GF exponential lookup table.
   * @param log_arr GF logarithmic lookup table.
   * @param gf_size Size of GF.
   * @return T Result of the multiplication within GF.
   */
  T gf_mul(T a, T b, const T* exp_arr, const T* log_arr, const uint32_t gf_size);

  /**
   * @brief Generates exponential and logarithm lookup tables for GF.
   * 
   * @tparam T Data type (e.g., uint8_t, uint16_t, uint32_t, uint64_t). 
   * @param exp_arr GF exponential lookup table.
   * @param log_arr GF logarithmic lookup table.
   * @param gf_exp Exponent of GF (2^gf_exp) within range [1,16].
   */
  void initialize_gf(T* exp_arr, T* log_arr, const uint16_t gf_exp);

  /**
   * @brief Performs carryless multiplication of two operands using intrinsic hardware instructions.
   * 
   * @tparam T Data type (e.g., uint8_t, uint16_t, uint32_t, uint64_t). 
   * @param a First operand.
   * @param b Second operand.
   * @param gf_exp Exponent of the Galois Field (2^gf_exp) within range [1,64].
   * @return uint64_t Result of the carryless multiplication.
   */
  T carryless_mul_fast(T a, T b, T gf_exp);

  /**
   * @brief Returns the exponential lookup table for outer GF.
   * 
   * @return std::vector<T> Exponential lookup table.
   */
  std::vector<T> get_exp_arr() { return exp_arr; };

  /**
   * @brief Returns the logarithmic lookup table for outer GF.
   * 
   * @return std::vector<T> Logarithmic lookup table.
   */
  std::vector<T> get_log_arr() { return log_arr; };

  /**
   * @brief Returns the exponential lookup table for inner GF.
   * 
   * @return std::vector<T> Exponential lookup table.
   */
  std::vector<T> get_exp_arr_in() { return exp_arr_in; };

  /**
   * @brief Returns the logarithmic lookup table for inner GF.
   * 
   * @return std::vector<T> Logarithmic lookup table.
   */
  std::vector<T> get_log_arr_in() { return log_arr_in; };

 private:
  std::vector<T> exp_arr;     ///< Exponential lookup table for Galois Field.
  std::vector<T> log_arr;     ///< Logarithmic lookup table for Galois Field.
  std::vector<T> exp_arr_in;  ///< Exponential lookup table for Inner Galois Field (eg. in RS2ID).
  std::vector<T> log_arr_in;  ///< Logarithmic lookup table for Inner Galois Field (eg. in RS2ID).
};

#endif  // ENCODER_GF_H
