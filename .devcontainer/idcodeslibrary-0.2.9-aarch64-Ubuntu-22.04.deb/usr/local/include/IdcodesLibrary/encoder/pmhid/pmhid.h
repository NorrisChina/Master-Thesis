#ifndef ENCODER_PMHID_H
#define ENCODER_PMHID_H

#include <vector>
#include "polymur-hash.h"

// polymur_init_params_from_seed(&pmh_params, 0xfedbca9876543210ULL);
template <typename T>
class PMHID {
 private:
  uint64_t tweak = 0xabcdef0123456789ULL;  // Tweak value for hash function
  PolymurHashParams pmh_params;

 public:
  /**
   * @brief Encodes a message using the Polymur hash function.
   *
   * @tparam M The data type of the message elements.
   * @param message The input message vector to be encoded.
   * @return uint64_t The encoded output as a 64-bit unsigned integer.
   */
  // Constructor to initialize the PMHID object with default parameters
  PMHID() {
    // Initialize the Polymur hash parameters
    polymur_init_params_from_seed(&pmh_params, 0xfedbca9876543210ULL);
  }
  uint64_t pmhid(const std::vector<T>& message);
};
#endif  // ENCODER_PMHID_H

// Explicit template instantiation
template class PMHID<uint8_t>;
template class PMHID<uint16_t>;
template class PMHID<uint32_t>;
template class PMHID<uint64_t>;
