#ifndef ENCODER_RS2ID_H
#define ENCODER_RS2ID_H

#include <vector>
#include "../rsid/rsid.h"
/**
 * @file rs2id.h
 * @brief Template class for encoding operations using Concatenated Reed-Solomon codes.
 *
 * This file contains the definition of the RS2ID class, which provides methods to encode messages
 * using Concatenated Reed-Solomon codes. It inherits from the RSID<T> class and utilizes Galois Field operations
 * for encoding.
 * 
 * The following methods are provided:
 * - rs2id: Evaluates a codeword symbol (Tag value) using Concatenated Reed-Solomon (RS2) as Tagging codes.
 * 
 * This class also includes private member objects for handling the lookup tables for Galois Field operations.
 * 
 * @tparam T Data type for the elements in the Galois Field (e.g., uint8_t, uint16_t, uint32_t, uint64_t).
 * 
 * @date July 1, 2025
 * @version 0.2.9.0
 * Proprietary Software License Agreement
 */
template <typename T>
class RS2ID : public RSID<T> {
 public:
  /**
   * @brief Evaluates a codeword symbol (Tag value) using Concatenated Reed-Solomon (RS2) as Tagging codes.
   * 
   * @tparam T Data type (e.g., uint8_t, uint16_t, uint32_t, uint64_t).
   * @param message Input message vector for RS2 encoding.
   * @param tag_pos tag position for returning a specific codeword symbol from outer codeword.
   * @param tag_pos_in tag position for returning a specific codeword symbol from inner codeword.
   * @param exp_arr Outer GF exponential lookup table.
   * @param log_arr Outer GF logarithmic lookup table.
   * @param exp_arr_in Inner GF exponential lookup table.
   * @param log_arr_in Inner GF logarithmic lookup table.
   * @param gf_exp Exponent of GF (2^gf_exp) within range [1,64].
   * @return T A symbol (Tag value) at the specified tag position.
   */
  T rs2id(const std::vector<T>& message, const T tag_pos, const T tag_pos_in, const T* exp_arr,
          const T* log_arr, const T* exp_arr_in, const T* log_arr_in, const uint16_t gf_exp);
};

#endif  // ENCODER_RS2ID_H
