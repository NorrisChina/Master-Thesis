#ifndef ENCODER_RMID_H
#define ENCODER_RMID_H

#include <bitset>
#include <numeric>
#include <vector>
#include "../gf/gf.h"

/**
 * @file rmid.h
 * @brief Template class for encoding operations using Reed-Muller codes.
 *
 * This file contains the definition of the RMID class, which provides methods to encode messages
 * using Reed-Muller codes. It inherits from the GF<T> class and utilizes Galois Field operations
 * for encoding.
 * 
 * The following methods are provided:
 * - rmid: Evaluates a codeword symbol (Tag value) using Reed-Muller (RM) as Tagging codes.
 * - generate_monomials: Generates a monomial vector for Reed-Muller (RM) codes based on order 'r' and number of variables 'm'.
 * 
 * This class also includes private member objects for handling the lookup tables for Galois Field operations.
 * 
 * @tparam T Data type for the elements in the Galois Field (e.g., uint8_t, uint16_t, uint32_t, uint64_t).
 * 
 * @date July 1, 2025
 * @version 0.2.9.0
 * Proprietary Software License Agreement
 */
template <typename T>
class RMID : public GF<T> {
 public:
  /**
   * @brief  Evaluates a codeword symbol (Tag value) using Reed-Muller (RM) as Tagging codes.
   * 
   * @tparam T Data type (e.g., uint8_t, uint16_t, uint32_t, uint64_t).
   * @param message Input message vector for RM encoding.
   * @param tag_pos tag position for returning a specific codeword symbol.
   * @param rm_order Order of RM codes.
   * @param exp_arr GF exponential lookup table.
   * @param log_arr GF logarithmic lookup table.
   * @param gf_exp Exponent of GF (2^gf_exp) within range [1,64], here equals the number of variables required (m).
   * @return T A symbol (Tag value) at the specified tag position.
   */
  T rmid(const std::vector<T>& message, const T tag_pos, const T rm_order, const T* exp_arr,
         const T* log_arr, const uint16_t gf_exp);

  /**
   * @brief Generates a monomial vector for Reed-Muller (RM) codes based on order 'r' and number of variable 'm'.
   *
   * @tparam T Data type (e.g., uint8_t, uint16_t, uint32_t, uint64_t).
   * @param rm_order Order of RM codes. 
   * @param eval_point_rm m evaluation points for Reed-Muller from the GF.
   * @param k_rm The number of message symbols encoded by RM codes in a chunk.  
   * @param exp_arr GF exponential lookup table.
   * @param log_arr GF logarithmic lookup table.
   * @param gf_exp Exponent of GF (2^gf_exp) within range [1,64], here equals the number of variables required (m). 
   * @return vector<T> Generated monomial vector.
   */
  std::vector<T> generate_monomials(const T rm_order, const std::vector<T> eval_point_rm,
                                    const T k_rm, const T* exp_arr, const T* log_arr,
                                    const uint16_t gf_exp);
};

#endif  // ENCODER_RMID_H
