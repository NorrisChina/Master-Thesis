#ifndef ENCODER_POLAR_H
#define ENCODER_POLAR_H

#include <itpp/comm/modulator.h>  // Modulators like BPSK
#include <itpp/itbase.h>          // Basic IT++ functions
#include <openssl/evp.h>
#include <bitset>
#include <cstdint>
#include <iostream>
#include <random>
#include <sstream>
#include <string>
#include <vector>
#include "polar_external.h"

/**
 * @file sha1id.h
 * @brief Template class for encoding operations using POLAR .
 *
 * This file contains the definition of the POLARFEC class, which provides methods to encode messages
 * using POLARFEC. It includes functionality to compute POLAR  for a given data vector.
 * 
 * The following methods are provided:
 * - sha1id: Computes POLAR for the given data and returns a symbol (Tag value) with gf_exp bits.
 * 
 * @tparam T Data type for the elements in the data vector (e.g., uint8_t, uint16_t, uint32_t, uint64_t).
 * 
 * @date July 1, 2025
 * @version 0.2.9.0
 * Proprietary Software License Agreement
 */
template <typename T>
class POLARFEC : public POLAR {
 private:
  //   uint32_t N = 64;
  //   uint32_t K = 32;
  // Member variablesint
 public:
  POLARFEC(uint32_t N, uint32_t K) : POLAR(N, K) {
    std::cout << "POLARFEC constructor called with N=" << N << ", K=" << K << std::endl;
  }
  //    {
  // this->N = N;
  // this->K = K;
  //uint32_t info_length = 32;
  //uint32_t code_length = 64;
  //const std::string construct_method = "Huawei Approx";
  //const double design_para = 0;
  //this->polar_obj = POLAR(info_length, code_length);  //,
  //                                                    //  construct_method,
  // design_para
  // );  // POLAR object for encoding and decoding operations
  //   }
  /**
   * @brief Computes POLAR for the given data.
   * 
   * @tparam T Data type (e.g., uint8_t, uint16_t, uint32_t, uint64_t). 
   * @param data Input data/message vector.
   * @param gf_exp The desired number of bits representing a codeword symbol.
   * @return T A symbol (Tag value) with gf_exp bits
   */
  std::vector<bool> encode_polarfec(std::vector<bool>& data);
  std::vector<bool> decode_polarfec(std::vector<double>& llr);
};

#endif  // ENCODER_POLAR_H
