#ifndef ENCODER_SHA256ID_H
#define ENCODER_SHA256ID_H

#include <openssl/evp.h>
#include <bitset>
#include <cstdint>
#include <iostream>
#include <sstream>
#include <string>
#include <vector>

/**
 * @file sha256id.h
 * @brief Template class for encoding operations using SHA-256 hash.
 *
 * This file contains the definition of the SHA256ID class, which provides methods to encode messages
 * using SHA-256 hash. It utilizes OpenSSL for hashing operations.
 * 
 * The following methods are provided:
 * - sha256id: Computes SHA-256 hash for the given data.
 * 
 * @tparam T Data type for the elements in the input data vector (e.g., uint8_t, uint16_t, uint32_t, uint64_t).
 * 
 * @date July 1, 2025
 * @version 0.2.9.0
 * Proprietary Software License Agreement
 */
template <typename T>
class SHA256ID {
 public:
  /**
   * @brief Computes SHA-256 hash for the given data.
   * 
   * @tparam T Data type (e.g., uint8_t, uint16_t, uint32_t, uint64_t). 
   * @param data Input data/message vector.
   * @param gf_exp The desired number of bits representing a codeword symbol.
   * @return T A symbol (Tag value) with gf_exp bits
   */
  T sha256id(const std::vector<T>& data, uint16_t gf_exp);
};

#endif  // ENCODER_SHA256ID_H
