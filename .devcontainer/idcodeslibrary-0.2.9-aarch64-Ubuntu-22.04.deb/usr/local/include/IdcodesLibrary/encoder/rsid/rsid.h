/**
 * @file rsid.h
 * @brief RSID encoding using Reed-Solomon (RS) as Tagging codes.
 *
 * This file contains the definition of the RSID class, which provides methods for
 * encoding messages using Reed-Solomon codes as tagging codes. The RSID class
 * inherits from the GF class and utilizes Galois Field arithmetic for encoding.
 * 
 * The RSID class supports encoding for different ranges of Galois Field exponents
 * and provides specialized methods for handling these ranges efficiently.
 * 
 * The following methods are provided:
 * - rsid: Evaluates a codeword symbol (Tag value) using Reed-Solomon (RS) as Tagging codes.
 * - rsid_upto_gf2x16: Evaluates a Tag value using Reed-Solomon (RS) for GF exp (2^n; n =[1,16]) using lookup tables.
 * - rsid_upto_gf2x64: Evaluates a Tag value using Reed-Solomon (RS) for GF exp (2^n; n =[17,64]) using Hardware CLMUL Instructions.
 * 
 * @tparam T The data type used for the operations.
 * 
 * @date July 1, 2025
 * @version 0.2.9.0
 * Proprietary Software License Agreement
 *
 */

#ifndef ENCODER_RSID_H
#define ENCODER_RSID_H

#include <vector>
#include "../gf/gf.h"

/**
 * @class RSID
 * @brief A class for RSID encoding, inheriting from GF.
 *
 * @tparam T The data type used for encoding.
 */
template <typename T>
class RSID : public GF<T> {
 public:
  /**
   * @brief Evaluates a codeword symbol (Tag value) using Reed-Solomon (RS) as Tagging codes.
   *
   * @tparam T Data type (e.g., uint8_t, uint16_t, uint32_t, uint64_t).
   * @param message Input message vector for RS encoding.
   * @param tag_pos Tag position for returning a specific codeword symbol.
   * @param exp_arr GF exponential lookup table.
   * @param log_arr GF logarithmic lookup table.
   * @param gf_exp Exponent of GF (2^gf_exp) within range [1,64].
   * @return T A symbol (Tag value) at the specified tag position.
   */
  T rsid(const std::vector<T>& message, T tag_pos, const T* exp_arr, const T* log_arr,
         const uint16_t gf_exp);
  /**
   * @brief Evaluates a Tag value using Reed-Solomon (RS) for GF exp (2^n; n =[1,16]) using lookup tables.
   * 
   * @tparam T Data type (e.g., uint8_t, uint16_t, uint32_t, uint64_t).
   * @param message Input message vector for RS encoding.
   * @param tag_pos Tag position for returning a specific codeword symbol.
   * @param exp_arr GF exponential lookup table.
   * @param log_arr GF logarithmic lookup table.
   * @param gf_size Size of GF [0, (2^gf_exp)-1]
   * @return T A symbol (Tag value) at the specified tag position.
   */
  T rsid_upto_gf2x16(const std::vector<T>& message, const T tag_pos, const T* exp_arr,
                     const T* log_arr, uint32_t gf_size);
  /**
   * @brief Evaluates a Tag value using Reed-Solomon (RS) for GF exp (2^n; n =[17,64]) using Hardware CLMUL Instructions.
   * 
   * @tparam T Data type (e.g., uint8_t, uint16_t, uint32_t, uint64_t).
   * @param message Input message vector for RS encoding.
   * @param tag_pos Tag position for returning a specific codeword symbol.
   * @param gf_exp Exponent of GF (2^gf_exp) within range [17,64].
   * @return uint64_t A symbol (Tag value) at the specified tag position.
   */
  uint64_t rsid_upto_gf2x64(const std::vector<T>& message, const uint64_t tag_pos,
                            const uint16_t gf_exp);
};

#endif  // ENCODER_RSID_H
