/**
 * @file dataprocessing.h
 * @brief Template class for various data processing operations.
 *
 * This file contains the definition of the DataProcessing class, which provides methods for generating
 * random sequences, reading data from files, converting strings to numerical forms, and generating message vectors.
 * 
 * The following methods are provided:
 * - generate_string_sequence: Generates a random string of a particular data type.
 * - read_inputfile_sequence: Reads the data from an input file.
 * - string_to_numeric: Converts a string to its numerical form.
 * - generate_message_vector: Generates a message vector.
 * - generate_random_tag_pos: Generates a random tag position.
 * 
 * @tparam T The type of data to be processed (e.g., uint8_t, uint16_t, uint32_t, uint64_t).
 * 
 * @date October 10, 2023
 * @version 1.0
 * Proprietary Software License Agreement
 */
#ifndef DATA_PROCESSING_H
#define DATA_PROCESSING_H

#include <bitset>
#include <chrono>
#include <fstream>
#include <iostream>
#include <random>
#include <string>
#include <vector>

template <typename T>
class DataProcessing {
 public:
  /**
   * @brief Generates a random string of a particular data type.
   * 
   * @tparam T Data type (e.g., uint8_t, uint16_t, uint32_t, uint64_t). 
   * @param length Length of the string.
   * @return vector<T> Generated string as a vector.
   */
  std::vector<T> generate_string_sequence(int length);
  /**
   * @brief Reads the data from an input file.
   * 
   * @tparam T Data type (e.g., uint8_t, uint16_t, uint32_t, uint64_t). 
   * @param filename Name of the file.
   * @param binary True if the file is binary, false otherwise.
   * @return vector<T> Processed data as a message vector.
   */
  std::vector<T> read_inputfile_sequence(const std::string& filename, bool binary);
  /**
   * @brief Converts a string to its numerical form.
   * 
   * @param str Input string.
   * @return vector<unsigned char> Numerical representation of the string.
   */
  static std::vector<unsigned char> string_to_numeric(const std::string& str);
  /**
   * @brief Generates a message vector.
   * 
   * @param size_in_B Size of the message in Bytes.
   * @param gf_exp Number of bits representing each element of the message vector
   * @return vector<T> message vector.
   */
  std::vector<T> generate_message_vector(size_t size_in_KB, uint16_t gf_exp);
  /**
   * @brief Generates a random tag position.
   * 
   * @param tags_size Minimum value of the tag position.
   * @return T Random tag position.
   */
  T generate_random_tag_pos(T tags_size);

  /**
   * @brief Creates a file with random data.
   * 
   * @param filepath Path to the file.
   * @param size_in_B Size of the file in Bytes.
   * @param gf_exp Number of bits representing each element of the message vector.
   */
  void create_file(const std::string& filepath, uint64_t size_in_B, uint16_t gf_exp);

  /**
   * @brief Reads data from a file and stores it in a vector.
   * 
   * @param filepath Path to the file.
   * @param gf_exp Number of bits representing each element of the message vector.
   * @return vector<T> Processed data as a message vector.
   */
  std::vector<T> read_file(const std::string& filepath, uint16_t gf_exp);
  std::string generate_string(int length);
};

#endif  // DATA_PROCESSING_H
