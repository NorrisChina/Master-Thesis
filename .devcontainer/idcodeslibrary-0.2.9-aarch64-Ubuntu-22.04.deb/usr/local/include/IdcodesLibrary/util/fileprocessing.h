#ifndef FILE_PROCESSING_H
#define FILE_PROCESSING_H

#include <chrono>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <map>
#include <set>
#include <sstream>
#include <string>
#include <vector>

/**
 * @file fileprocessing.h
 * @brief A class for processing files and handling data frames.
 *
 * This file contains the definition of the FileProcessing class, which provides methods to handle
 * file operations and manage data frames. It includes functionalities to get the current timestamp,
 * add values to a data frame, and save data frames to a CSV file.
 * 
 * The following methods and structures are provided:
 * - gettimestamp: Returns the current timestamp in YYYYMMDDHHMMSS format.
 * - DataFrame: A structure to hold generated data, with a method to add values to the data frame.
 * - save_to_csv: Saves benchmark times to a CSV file.
 * 
 * @date October 10, 2023
 * @version 1.0
 * Proprietary Software License Agreement
 */
class FileProcessing {
 public:
  /**
   * @brief Get the current timestamp in YYYYMMDDHHMMSS format.
   * 
   * @return std::string The current timestamp.
   */
  std::string gettimestamp();

  /**
   * @struct DataFrame
   * @brief A structure to hold generated data.
   * 
   * This structure contains a map where the key is a string and the value is a vector of doubles.
   */
  struct DataFrame {
    std::map<std::string, std::vector<double>> data;
    /**
     * @brief Add a value to the data frame under the specified key.
     * 
     * @param key The key under which the value will be stored.
     * @param value The value to be added to the data frame.
     */
    void push_back(const std::string& key, double value) { data[key].push_back(value); }
  };

  /**
   * @brief Save benchmark times to a CSV file.
   * 
   * @param df_vector A vector of DataFrame objects to be saved.
   * @param filepath The path to the CSV file where the data will be saved.
   */
  void save_to_csv(const std::vector<DataFrame>& df_vector, const std::string filepath);
};

#endif  // FILE_PROCESSING_H
