#pragma once
#include <cstdint>
// Type definitions for the bits
using B_8 = uint8_t;
using B_16 = uint16_t;
using B_32 = uint32_t;
using B_64 = uint64_t;

// File to save the GF Tables
constexpr char GF_OUTER_TABLE_FILE[] = "./GF_OUTER_Tables.txt";
constexpr char GF_INNER_TABLE_FILE[] = "./GF_INNER_Tables.txt";

// Primitive element for the field
static constexpr uint64_t primitive_element = 0x02;

// Precomputed reduction polynomials for GF(2^n) where n = 1 to 64
static constexpr __uint128_t FIELD_GEN_POLY[] = {
    0x3,                           // 1-bit GF(2^1)
    0x7,                           // 2-bit GF(2^2)
    0xb,                           // 3-bit GF(2^3)
    0x13,                          // 4-bit GF(2^4)
    0x25,                          // 5-bit GF(2^5)
    0x43,                          // 6-bit GF(2^6)
    0x83,                          // 7-bit GF(2^7)
    0x11d,                         // 8-bit GF(2^8)
    0x211,                         // 9-bit GF(2^9)
    0x409,                         // 10-bit GF(2^10)
    0x805,                         // 11-bit GF(2^11)
    0x1053,                        // 12-bit GF(2^12)
    0x201b,                        // 13-bit GF(2^13)
    0x402b,                        // 14-bit GF(2^14)
    0x8003,                        // 15-bit GF(2^15)
    0x1002d,                       // 16-bit GF(2^16)
    0x20009,                       // 17-bit GF(2^17)
    0x40027,                       // 18-bit GF(2^18)
    0x80027,                       // 19-bit GF(2^19)
    0x100009,                      // 20-bit GF(2^20)
    0x200005,                      // 21-bit GF(2^21)
    0x400003,                      // 22-bit GF(2^22)
    0x800021,                      // 23-bit GF(2^23)
    0x100001b,                     // 24-bit GF(2^24)
    0x2000009,                     // 25-bit GF(2^25)
    0x4000047,                     // 26-bit GF(2^26)
    0x8000027,                     // 27-bit GF(2^27)
    0x10000009,                    // 28-bit GF(2^28)
    0x20000005,                    // 29-bit GF(2^29)
    0x40000053,                    // 30-bit GF(2^30)
    0x80000009,                    // 31-bit GF(2^31)
    0x1000000af,                   // 32-bit GF(2^32)
    0x200000053,                   // 33-bit GF(2^33)
    0x4000000e7,                   // 34-bit GF(2^34)
    0x800000005,                   // 35-bit GF(2^35)
    0x1000000077,                  // 36-bit GF(2^36)
    0x200000003f,                  // 37-bit GF(2^37)
    0x4000000063,                  // 38-bit GF(2^38)
    0x8000000011,                  // 39-bit GF(2^39)
    0x10000000039,                 // 40-bit GF(2^40)
    0x20000000009,                 // 41-bit GF(2^41)
    0x4000000003f,                 // 42-bit GF(2^42)
    0x80000000059,                 // 43-bit GF(2^43)
    0x100000000065,                // 44-bit GF(2^44)
    0x20000000001b,                // 45-bit GF(2^45)
    0x40000000012f,                // 46-bit GF(2^46)
    0x800000000021,                // 47-bit GF(2^47)
    0x10000000000b7,               // 48-bit GF(2^48)
    0x2000000000071,               // 49-bit GF(2^49)
    0x400000000001d,               // 50-bit GF(2^50)
    0x800000000004b,               // 51-bit GF(2^51)
    0x10000000000009,              // 52-bit GF(2^52)
    0x20000000000047,              // 53-bit GF(2^53)
    0x4000000000007d,              // 54-bit GF(2^54)
    0x80000000000047,              // 55-bit GF(2^55)
    0x100000000000095,             // 56-bit GF(2^56)
    0x20000000000002d,             // 57-bit GF(2^57)
    0x400000000000063,             // 58-bit GF(2^58)
    0x80000000000007b,             // 59-bit GF(2^59)
    0x1000000000000003,            // 60-bit GF(2^60)
    0x2000000000000027,            // 61-bit GF(2^61)
    0x4000000000000069,            // 62-bit GF(2^62)
    0x8000000000000003,            // 63-bit GF(2^63)
    (__uint128_t(1) << 64) | 0x1B  // 64-bit GF(2^64), high bit is stored separately
};

// Bit ranges predefined for the program
constexpr int BIT_RANGE_1 = 1;
constexpr int BIT_RANGE_8 = 8;
constexpr int BIT_RANGE_16 = 16;
constexpr int BIT_RANGE_32 = 32;
constexpr int BIT_RANGE_64 = 64;

// Type selection based on value ranges
template <int value>
struct SelectType {
  static_assert(value >= 1 && value <= 64, "value must be between 1 and 64");
  // clang-format off
  using type = typename std::conditional<(value >= 1 && value <= 8), uint8_t,    // Use uint8_t for 1-8
               typename std::conditional<(value >= 9 && value <= 16), uint16_t,  // Use uint16_t for 9-16
               typename std::conditional<(value >= 17 && value <= 32),uint32_t,  // Use uint32_t for 17-32
                                                                      uint64_t   // Use uint64_t for 33-64
                                                                      >::type
                                                                      >::type
                                                                      >::type;
  // clang-format off
};